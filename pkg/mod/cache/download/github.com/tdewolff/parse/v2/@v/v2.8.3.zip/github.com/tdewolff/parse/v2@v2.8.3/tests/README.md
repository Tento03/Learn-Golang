# Fuzzing parse

Fuzz testing for `parse` using [go-fuzz](https://github.com/dvyukov/go-fuzz). Pull requests to add more corpora or testers are appreciated.

To run the tests, install `go-fuzz`:

```
go get -u github.com/dvyukov/go-fuzz/go-fuzz github.com/dvyukov/go-fuzz/go-fuzz-build

cd $GOPATH/github.com/tdewolff/parse/tests/number

go-fuzz-build
go-fuzz -bin fuzz-fuzz.zip
```

If restarts is not close to `1/10000`, something is probably wrong. If not finding new corpus for a while, restart the fuzzer.
