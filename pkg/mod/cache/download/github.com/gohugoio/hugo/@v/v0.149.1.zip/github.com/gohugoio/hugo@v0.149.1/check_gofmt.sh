#!/usr/bin/env bash
diff <(gofmt -d .) <(printf '')