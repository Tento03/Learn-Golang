package identitytesting

import "github.com/gohugoio/hugo/identity"

const TestIdentity = identity.StringIdentity("__testIdentity")
