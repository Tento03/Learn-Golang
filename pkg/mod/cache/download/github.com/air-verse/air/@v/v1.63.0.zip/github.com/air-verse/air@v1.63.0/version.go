package main

var (
	airVersion string
	goVersion  string
)
